import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouterdetailsComponent } from './routerdetails.component';

describe('RouterdetailsComponent', () => {
  let component: RouterdetailsComponent;
  let fixture: ComponentFixture<RouterdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RouterdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RouterdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-routerdetails',
  templateUrl: './routerdetails.component.html',
  styleUrls: ['./routerdetails.component.css']
})
export class RouterdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
